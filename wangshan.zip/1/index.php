<?php
require 'OneNetApi.php';

$apikey = 'W2O=95GBBMM=gSMRebwVo4oOud8=';
$apiurl = 'http://api.heclouds.com';

//创建api对象
$sm = new OneNetApi($apikey, $apiurl);

$device_id = '609161';
$datastream_id='wendu';
$d_stream = $sm->datapoint_get($device_id,$datastream_id);
$error_code = 0;
$error = '';
if (empty($d_stream)) {
    //处理错误信息
    $error_code = $sm->error_no();
    $error = $sm->error();
}

//展现设备
$str=(string)$d_stream['datastreams'][0]['datapoints'][0]['value'];
//var_dump($str);