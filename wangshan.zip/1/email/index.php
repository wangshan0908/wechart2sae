<?php

//引入发送邮件类
require("smtp.php"); 
require 'OneNetApi.php';//yin ru wen jian 
$apikey = 'W2O=95GBBMM=gSMRebwVo4oOud8=';
$apiurl = 'http://api.heclouds.com';

//创建api对象
$sm = new OneNetApi($apikey, $apiurl);

$device_id = '609161';
$datastream_id='wendu';
$sm = new OneNetApi($apikey, $apiurl);
$d_stream = $sm->datapoint_get($device_id,$datastream_id);
$str1=(string)$d_stream['datastreams'][0]['datapoints'][0]['value'];

//使用163邮箱服务器
$smtpserver = "smtp.163.com";
//$smtpserver = "smtp.qq.com";
//163邮箱服务器端口 
$smtpserverport = 25;
//$smtpserverport = 587;
//你的163服务器邮箱账号
$smtpusermail = "Yamacage_s@163.com";
//$smtpusermail = "495644957@qq.com";
//收件人邮箱
$smtpemailto = "906655282@qq.com";
//你的邮箱账号(去掉@163.com)
$smtpuser = "Yamacage_s";//SMTP服务器的用户帐号 
//$smtpuser = "495644957";//SMTP服务器的用户帐号 
//你的邮箱密码
$smtppass = "wangshan7357271"; //SMTP服务器的用户密码 
//$smtppass = "@wangshan"; //SMTP服务器的用户密码 
//邮件主题 
$mailsubject = "宁夏大学传感器预警";
//邮件内容 
$mailbody = "亲爱的用户你好，你的温度传感器超出了预定温度！现在的温度是：".$str1."°C！";
//邮件格式（HTML/TXT）,TXT为文本邮件 
$mailtype = "TXT";
//这里面的一个true是表示使用身份验证,否则不使用身份验证. 
$smtp = new smtp($smtpserver,$smtpserverport,true,$smtpuser,$smtppass);
//是否显示发送的调试信息 
$smtp->debug = true;
//发送邮件
$smtp->sendmail($smtpemailto, $smtpusermail, $mailsubject, $mailbody, $mailtype); 


?>