<?php
  define('APP_DEBUG',TRUE); // 开启调试模式
   require './ThinkPHP/ThinkPHP.php';
