<?php if (!defined('THINK_PATH')) exit();?><html>
 <head>
   <title>Select Data</title>
 </head>
 <body>
    <h1>hello,data!</h1>
	<?php if(is_array($data)): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>设备id：<?php echo ($vo["did"]); ?><br/>
	API-KEY:<?php echo ($vo["dkey"]); ?><br/>
	数据：<?php echo ($vo["dt"]); ?><br/>
	控制命令：<?php echo ($vo["ctrl"]); ?><br/><?php endforeach; endif; else: echo "" ;endif; ?>

	
 </body>
</html>