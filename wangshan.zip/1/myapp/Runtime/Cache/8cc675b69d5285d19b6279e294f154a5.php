<?php if (!defined('THINK_PATH')) exit();?>﻿
<html>
 <head>
   <title>Select Data</title>
 </head>
 <body>
    <h1>hello,form!</h1>

<FORM method="post" action="__URL__/insert">
标题：<INPUT type="text" name="title"><br/>
内容：<TEXTAREA name="content" rows="5" cols="45"></TEXTAREA><br/>
时间：<INPUT type="text" name="create_time"><br>
<INPUT type="submit" value="提交">
</FORM>
	
 </body>
</html>