<?php if (!defined('THINK_PATH')) exit();?><html>
 <head>
   <title>Select Data</title>
 </head>
 <body>
    <h1>hello,read!</h1>

<table>
<tr>
    <td>id:</td>
    <td><?php echo ($data["id"]); ?></td>
</tr>
<tr>
    <td>标题：</td>
    <td><?php echo ($data["title"]); ?></td>
</tr>
<tr>
    <td>内容：</td>
    <td><?php echo ($data["content"]); ?></td>
</tr>
</table>
	
 </body>
</html>