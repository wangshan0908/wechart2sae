<?php
// 本类由系统自动生成，仅供测试用途
class IndexAction extends Action {
    public function index(){
		//$Data=M('Data');
		//$this->data=$Data->select();
		//$this->display();
		
		$Data = M('zigbee'); // 实例化Data数据模型
		
		if($_REQUEST['dt'])
		{
			$d['dt']=$_REQUEST['dt'];
			$Data->where('did="'.$_REQUEST['did'].'"and dkey="'.$_REQUEST['key'].'"')->setField(dt,$d['dt']);
		}
		$r=$Data->where('did="'.$_REQUEST['did'].'"and dkey="'.$_REQUEST['key'].'"')->find();
		echo $r['ctrl'];
		
		
		
        $this->data = $Data->select();
        $this->display();
		
		}
}