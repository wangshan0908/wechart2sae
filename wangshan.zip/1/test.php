<?php
/*******************************onenet文件引入及参数定义*********************************************/
require 'OneNetApi.php';//yin ru wen jian 



/**************************************onenet文件引入及参数定义*************************************/
/**
  * wechat php test
  */

//define your token


define("TOKEN", "wangshan");
$wechatObj = new wechatCallbackapiTest();
//$wechatObj->valid();
$wechatObj->responseMsg();

class wechatCallbackapiTest
{
	public function valid()
    {
        $echoStr = $_GET["echostr"];

        //valid signature , option
        if($this->checkSignature()){
        	echo $echoStr;
        	exit;
        }
    }

    public function responseMsg()
    {
		//get post data, May be due to the different environments
		$postStr = $GLOBALS["HTTP_RAW_POST_DATA"];

		
      	//extract post data
		if (!empty($postStr)){
                
              	$postObj = simplexml_load_string($postStr, 'SimpleXMLElement', LIBXML_NOCDATA);
                $fromUsername = $postObj->FromUserName;
                $toUsername = $postObj->ToUserName;
                $keyword = trim($postObj->Content);
                $time = time();
                $textTpl = "<xml>
							<ToUserName><![CDATA[%s]]></ToUserName>
							<FromUserName><![CDATA[%s]]></FromUserName>
							<CreateTime>%s</CreateTime>
							<MsgType><![CDATA[%s]]></MsgType>
							<Content><![CDATA[%s]]></Content>
							<FuncFlag>0</FuncFlag>
							</xml>";             
				if(!empty( $keyword ))
                {
					//sendMessage($fromUsername,"你好啊同学！！！！");
              		$msgType = "text";
                	$contentStr = "Welcome to Ningxiadaxue Tnternet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！";
                	
				//创建api对象
				$apikey = 'W2O=95GBBMM=gSMRebwVo4oOud8=';
                $apiurl = 'http://api.heclouds.com';

                $device_id = '609161';
                $datastream_id='wendu';
                $sm = new OneNetApi($apikey, $apiurl);
				
				if($keyword=="传感器")
				{
				$d_stream = $sm->datapoint_get($device_id,$datastream_id);
		        $str1=(string)$d_stream['datastreams'][0]['datapoints'][0]['value'];	
				$contentStr = "亲爱的用户".$fromUsername."你好，你查询的宁夏大学的气温为:".$str1."°C！";
				}
				else if($keyword=="开灯")
				{
					$this->Light(1);
				$url='http://api.cd6969.com/api/gw/domb/?did=10001&key=sdfrghjukilf5j2fg&t=4&ctrl=L2ON';  
                $html = file_get_contents($url);  
				 $contentStr="Welcome to Ningxiadaxue Internet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！\n 你的灯已经打开！";
				}else if($keyword=="关灯")
				{
					$this->Light(0);
				$url='http://api.cd6969.com/api/gw/domb/?did=10001&key=sdfrghjukilf5j2fg&t=4&ctrl=L2OFF';  
                $html = file_get_contents($url);  
				 $contentStr="Welcome to Ningxiadaxue Internet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！\n 你的灯已经关闭！";
				}
				else if($keyword=="温度")
				{
					$this->Light(0);
				$url='http://api.cd6969.com/api/gw/domb/?did=10001&key=sdfrghjukilf5j2fg&t=4';  
                $html = file_get_contents($url);  
				$url_wendu= substr($html,9,2);
				 $contentStr="Welcome to Ningxiadaxue Internet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！\n您室内温度为".$url_wendu."°C！";
				}
				else if($keyword=="湿度")
				{
					$this->Light(0);
				$url='http://api.cd6969.com/api/gw/domb/?did=10001&key=sdfrghjukilf5j2fg&t=4';  
                $html = file_get_contents($url);  
				$url_shidu= substr($html,11,2);
				 $contentStr="Welcome to Ningxiadaxue Internet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！\n您室内湿度为".$url_shidu."%RH";
			
				}
				
					
					
					$resultStr = sprintf($textTpl, $fromUsername, $toUsername, $time, $msgType, $contentStr);
                	echo $resultStr;
                }else{
                	echo "Welcome to Ningxiadaxue Tnternet of things world!
					欢迎！\n 你可以尝试的关键词包括：传感器、开灯、关灯！";
                }

        }else {
        	echo "";
        	exit;
        }
    }
	public function Light($int){
		        $apikey = 'W2O=95GBBMM=gSMRebwVo4oOud8=';
                $apiurl = 'http://api.heclouds.com';
		        $device_id = '609161';
                $datastreams_id='switch';
                $sm = new OneNetApi($apikey, $apiurl);
				$datas=array(time()=>$int);
                $sm->datapoint_add($device_id,$datastreams_id,$datas);
		
	}
	
	public function getData($datastream)
	{
		$d_stream = $sm->datapoint_get($device_id,$datastream_id);
		$str=$d_stream['datastreams'][0]['datapoints'][0]['value'];
		return $str;
	}	

    
   function sendMessage($touser,$content){
	    
	$APPID="wxb9e5517420f3a940";
    $APPSECRET="de352da1440961f8da6b984cce6fcca5";
    
    $TOKEN_URL="https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=".$APPID."&secret=".$APPSECRET;
    
   // $json=file_get_contents($TOKEN_URL);
   $ch=curl_init();
   curl_setopt($ch,CURLOPT_URL,$TOKEN_URL);
   curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
   curl_setopt($ch,CURLOPT_SSL_VERIFYPEER,FALSE);
   curl_setopt($ch,CURLOPT_SSL_VERIFYHOST,FALSE);
   $json=curl_exec($ch);
   curl_close($ch);
    $result=json_decode($json);
    $ACC_TOKEN=$result->access_token;
	//echo $ACC_TOKEN;
	
	 $data = '{
        "touser":"'.$touser.'",
        "msgtype":"text",
        "text":
        {
             "content":"'.$content.'"
        }
    }';
    
    $url = "https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=".$ACC_TOKEN;
    
    $result = https_post($url,$data);
    $final = json_decode($result);
   }

function https_post($url,$data)
{
    $curl = curl_init();
    curl_setopt($curl, CURLOPT_URL, $url); 
    curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($curl, CURLOPT_POST, 1);
    curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
    $result = curl_exec($curl);
    if (curl_errno($curl)) {
       return 'Errno'.curl_error($curl);
    }
    curl_close($curl);
    return $result;
}
	
	private function checkSignature()
	{
        $signature = $_GET["signature"];
        $timestamp = $_GET["timestamp"];
        $nonce = $_GET["nonce"];	
        		
		$token = TOKEN;
		$tmpArr = array($token, $timestamp, $nonce);
		sort($tmpArr);
		$tmpStr = implode( $tmpArr );
		$tmpStr = sha1( $tmpStr );
		
		if( $tmpStr == $signature ){
			return true;
		}else{
			return false;
		}
	}
	
	
	
}


	  
	

?>